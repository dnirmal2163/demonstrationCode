// Name-Deepak Nirmal and Student number-8812163
const express = require('express');
const path = require('path');

const mongoose = require('mongoose');
const { get } = require('http');
const { Console } = require('console');
mongoose.connect('mongodb://127.0.0.1:27017/awesomestore', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const Order = mongoose.model('Order', {
  name:String,
  address:String,
  city:String,
  province:String,
  email:String,
  drills:String,
  alanKeys:String,
  wrenches:String,
  hackSaws:String,
  tapeMeasures:String,
  costOfDrills:Number,
  costOfAlanKeys:Number,
  costOfWrenches:Number,
  costOfHackSaws:Number,
  costOfTapeMeasures:Number,
  total:Number,
  tax:Number,
  finalCost:Number
});

var allOrders;

var myApp = express();
myApp.use(express.urlencoded({extended:false}));

myApp.set('views', path.join(__dirname, 'views'));

myApp.use(express.static(__dirname+'/public'));
myApp.set('view engine', 'ejs');

var drillsInv, alanKeysInv, wrenchesInv, hackSawsInv, tapeMeasuresInv,errors;

myApp.get('/', function(req, res){
    res.render('form'); 
    drillsInv=25;
    alanKeysInv=25;
    wrenchesInv=25;
    hackSawsInv=25;
    tapeMeasuresInv=25;
    errors="";
    console.log("reached get");
});

myApp.post('/', function(req, res){

    console.log("Reached Post");

    var name = req.body.customerName;
    var address = req.body.address;
    var city = req.body.city;
    var province = req.body.province;
    var phone = req.body.phoneNumber;
    var email = req.body.email;

    var drills = req.body.drills;
    var alanKeys = req.body.alanKeys;
    var wrenches = req.body.wrenches;
    var hackSaws = req.body.hackSaws;
    var tapeMeasures = req.body.tapeMeasures;
   
    errors = "";

    var nameRegExp = /^[A-Za-z]+\s?[A-Za-z]*$/;

    if(!(nameRegExp.test(name))){
        errors +=  "The name needs to be set of characters<br>";
    }
    
    var addressRegExp = /^[A-Za-z0-9]+\s?[A-Za-z0-9]+\s?[A-Za-z0-9]*?\s?[A-Za-z0-9]*?$/;

    if(!(addressRegExp.test(address))){
        errors +=  "Please enter a valid address<br>";
    }

    var cityRegExp = /^[A-Za-z]+$/;

    if(!(cityRegExp.test(city))){
        errors +=  "Please enter a valid city<br>";
    }
    
    var provinceRegExp = /^NL|PE|NS|NB|QC|ON|MB|SK|AB|BC|YT|NT|NU$/;

    if(!(provinceRegExp.test(province))){
        errors +=  "Please enter a valid province<br>";
    }

    var phoneRegExp = /^[0-9]{10}$/;

    if(!(phoneRegExp.test(phone))){
        errors +=  "Please enter a valid phone number<br>";
    }
    
    var emailRegExp = /^[a-zA-Z0-9]+@[a-zA-Z]+.com$/;

    if(!(emailRegExp.test(email))){
        errors +=  "Please enter a valid email address<br>";
    }

    if(drillsInv<=0){
      errors += "Drills out of stock<br>";

    }

    if(alanKeysInv<=0){
      errors += "Alan keys are out of stock<br>";

    }

    if(wrenchesInv<=0){
      errors += "Wrenches are out of stock<br>";
    }

    if(hackSawsInv<=0){
      errors += "Hack saws are out of stock<br>";

    }

    if(tapeMeasuresInv<=0){
      errors += "Tape measures are out of stock<br>";

    }

    if(drills>drillsInv){
      errors += "Only "+drillsInv+" Drills are available<br>";
    }

    if(alanKeys>alanKeysInv){
      errors += "Only " +alanKeysInv+" alan keys are available<br>";
    }

    if(wrenches>wrenchesInv){
      errors += "Only " +wrenchesInv+" wrenches are available<br>";
    }

    if(hackSaws>hackSawsInv){
      errors += "Only " +hackSawsInv+" hacks saws are available<br>";
    }

    if(tapeMeasures>tapeMeasuresInv){
      errors += "Only " +tapeMeasuresInv+" tape measures are available<br>";
    }

    var qtyRegex=/^[0-9]*$/;

    if(!(qtyRegex.test(drills))){
      errors +=  "Please enter a valid quantity for drills<br>";
  }

  if(!(qtyRegex.test(alanKeys))){
    errors +=  "Please enter a valid quantity for alan keys<br>";
  }

  if(!(qtyRegex.test(wrenches))){
    errors +=  "Please enter a valid quantity for wrenches<br>";
}

if(!(qtyRegex.test(hackSaws))){
  errors +=  "Please enter a valid quantity for hacksaws<br>";
}

if(!(qtyRegex.test(tapeMeasures))){
  errors +=  "Please enter a valid quantity for tape Measures<br>";
}









    if(errors==""){

      

      
       
        var costOfDrills = 50*drills;
        var costOfAlanKeys = 25*alanKeys;
        var costOfWrenches = 20*wrenches;
        var costOfHackSaws = 7*hackSaws;
        var costOfTapeMeasures = 5*tapeMeasures;
        
        var total = costOfDrills+costOfAlanKeys+costOfTapeMeasures+costOfHackSaws+costOfWrenches;
        var finalCost;
        var tax;

        switch(province) {
            case "AB":
              tax = 0.05;
              finalCost = total+total*tax;
              break;
            case "BC":
              tax = 0.12;
              finalCost = total+total*tax;
              break;
            case "MB":
              tax = 0.12;
              finalCost = total+total*tax;
              break;
            case "NB":
              tax = 0.15;
              finalCost = total+total*tax;
              break;
            case "NL":
              tax=0.15;
              finalCost = total+total*tax;
              break;
            case "NT":
              tax=0.05;
              finalCost = total+total*tax;
              break;
            case "NS":
              tax=0.15;
              finalCost = total+total*tax;
              break;
            case "NU":
              tax=0.05;
              finalCost = total+total*tax;
              break;
            case "ON":
              finalCost = total+total*0.13;
              break;
            case "PE":
              tax = 0.15;
              finalCost = total+total*tax;
              break;
            case "QC":
              tax=0.14;
              finalCost = total+total*tax;
              break;
            case "NT":
              finalCost = total+total*tax;
              break;
            case "SK":
                tax=0.11;
                finalCost = total+total*tax;
                break;
            case "YT":
                tax=0.05;
                finalCost = total+total*tax;
                break;



          }

          tax=((finalCost-total)/total)*100;

          
          var pageData = {
            name:name,
            address:address,
            city:city,
            province:province,
            email:email,
            drills:drills,
            alanKeys:alanKeys,
            wrenches:wrenches,
            hackSaws:hackSaws,
            tapeMeasures:tapeMeasures,
            costOfDrills:costOfDrills,
            costOfAlanKeys:costOfAlanKeys,
            costOfWrenches:costOfWrenches,
            costOfHackSaws:costOfHackSaws,
            costOfTapeMeasures:costOfTapeMeasures,
            total:total,
            tax:tax,
            finalCost:finalCost,
            errors:errors
            
        }

        tableData={
            name:name,
            address:address,
            city:city,
            province:province,
            email:email,
            drills:drills,
            alanKeys:alanKeys,
            wrenches:wrenches,
            hackSaws:hackSaws,
            tapeMeasures:tapeMeasures,
            costOfDrills:costOfDrills,
            costOfAlanKeys:costOfAlanKeys,
            costOfWrenches:costOfWrenches,
            costOfHackSaws:costOfHackSaws,
            costOfTapeMeasures:costOfTapeMeasures,
            total:total,
            tax:tax,
            finalCost:finalCost
            
          
      }

        if(finalCost>10){
          res.render('form',pageData);

          drillsInv=drillsInv-drills;
          alanKeysInv=alanKeysInv-alanKeys;
          wrenchesInv=wrenchesInv-wrenches;
          hackSawsInv=hackSawsInv-hackSaws;
          tapeMeasuresInv=tapeMeasuresInv-tapeMeasures;

          allOrders = new Order(tableData);
          allOrders.save().then(function(){
            console.log('New order created successfully');
        });
        }

        else{
          errors+="A total purchase of $10 needs to be made to process the order<br>"
          res.render('form',{errors:errors});
        }

          

    }

    else{
      var pageData = {
        
        errors:errors
        
    }
      res.render('form',pageData);
    }


    
});

myApp.get('/allOrders', function(req, res){

 
  
 
    Order.find({}).exec(function(err, orders){
      if(typeof(orders)!='undefined'){
        res.render('allOrders', {orders:orders});
      }

      else{
        res.redirect('/form');
        alert("Redirected to form page since no orders exist");
      }
      
        
    });
  
  });

  myApp.get('/allOrders/:orderid', function(req, res){
    
    
        var orderid = req.params.orderid;
        
        Order.findByIdAndDelete({_id: orderid}).exec(function(err, order){
           
            
                
                console.log("Order has been deleted successfully");
            
            
        });
        res.send("Close the window and click \"Show all Orders\" to see the updated table")
        
});

myApp.listen(8080);

console.log('Everything executed fine.. website at port 8080....');